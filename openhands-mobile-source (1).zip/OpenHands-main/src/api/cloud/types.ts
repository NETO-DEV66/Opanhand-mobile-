/**
 * Minimal slice of the OpenHands cloud organization shape that the GUI needs
 * to render the backend selector. Full shape lives in the OpenHands repo;
 * we keep only the fields actually read by this codebase.
 */
export interface CloudOrganization {
  id: string;
  name: string;
  is_personal?: boolean;
  /**
   * Whether the org should be offered in the UI. The cloud sets this per org
   * from its `HIDE_PERSONAL_WORKSPACES` policy. Optional on purpose: an
   * app-server that predates the field omits it, and an absent flag means
   * "visible" — only an explicit `false` hides an org.
   */
  is_visible?: boolean;
}

export interface CloudOrganizationsResponse {
  items: CloudOrganization[];
  current_org_id: string | null;
}

/**
 * Subset of OpenHands' OrganizationMember that the GUI reads. Returned by
 * `GET /api/organizations/{orgId}/me`. The relationship between the org and
 * the current user is the source of truth for "is this a personal
 * workspace?" — namely `org_id === user_id`.
 */
export interface CloudOrganizationMember {
  org_id: string;
  user_id: string;
  email?: string | null;
  role?: string;
  status?: string;
}

/**
 * Response from `GET /api/keys/current`. Identifies the org the calling
 * API key is scoped to. Legacy keys without an org binding cause the
 * upstream to return HTTP 400 instead of producing this shape — the
 * caller catches that case rather than expecting a partial response.
 */
export interface CloudApiKeyMetadata {
  id: string;
  name: string;
  org_id: string | null;
  user_id: string;
  auth_type: string;
}

/**
 * Server-derived Super Admin setup-guide steps, from
 * `GET /api/admin/setup-state` on an OpenHands Enterprise backend.
 */
export interface CloudSetupGuideSteps {
  org_llm: boolean;
  mcp_server: boolean;
  automation: boolean;
  invite: boolean;
}

/**
 * Subset of the enterprise setup-state the GUI reads. `guide_steps` is
 * non-null only for the first Super Admin while the guide has an
 * organization and has not been dismissed.
 */
export interface CloudSetupState {
  guide_org_id: string | null;
  guide_dismissed: boolean;
  guide_steps: CloudSetupGuideSteps | null;
}
