import { useTranslation } from "react-i18next";
import { I18nKey } from "#/i18n/declaration";
import type { Automation } from "#/types/automation";
import { ToggleSwitch } from "#/components/features/automations/toggle-switch";
import { KebabMenu } from "#/components/features/automations/kebab-menu";
import PowerIcon from "#/icons/power.svg?react";
import DownloadIcon from "#/icons/download.svg?react";
import TrashIcon from "#/icons/trash.svg?react";
import EditIcon from "#/icons/u-edit.svg?react";
import PlayIcon from "#/icons/play.svg?react";
import { ActiveStatusBadge } from "./active-status-badge";

interface DetailHeaderProps {
  automation: Automation;
  onToggle: () => void;
  /** When provided (and the user can manage), the kebab menu shows an Edit entry. */
  onEdit?: () => void;
  onDelete: () => void;
  onExport: () => void;
  onDownloadTarball: () => void;
  onRunNow?: () => void;
  isRunningNow?: boolean;
  /** Whether the caller may mutate this automation (manage perm or owner). */
  canManage?: boolean;
  /**
   * Whether the caller may flip the enabled switch. Defaults to `canManage`;
   * pass `false` for a disabled automation the caller did not create, since
   * non-creators may only turn automations off.
   */
  canToggle?: boolean;
}

export function DetailHeader({
  automation,
  onToggle,
  onEdit,
  onDelete,
  onExport,
  onDownloadTarball,
  onRunNow,
  isRunningNow = false,
  canManage = true,
  canToggle = canManage,
}: DetailHeaderProps) {
  const { t } = useTranslation("openhands");

  const kebabItems = [
    // Read-only items are always available to anyone who can view.
    {
      label: t(I18nKey.AUTOMATIONS$EXPORT),
      icon: <DownloadIcon className="size-4" />,
      onClick: onExport,
    },
    {
      label: t(I18nKey.AUTOMATIONS$DOWNLOAD_TARBALL),
      icon: <DownloadIcon className="size-4" />,
      onClick: onDownloadTarball,
    },
    // Write items — only when the user may mutate this automation.
    ...(canManage && onEdit
      ? [
          {
            label: t(I18nKey.AUTOMATIONS$EDIT),
            icon: <EditIcon className="size-4" />,
            onClick: onEdit,
          },
        ]
      : []),
    ...(canToggle
      ? [
          {
            label: automation.enabled
              ? t(I18nKey.AUTOMATIONS$TURN_OFF)
              : t(I18nKey.AUTOMATIONS$TURN_ON),
            icon: <PowerIcon className="size-4" />,
            onClick: onToggle,
          },
        ]
      : []),
    ...(canManage
      ? [
          {
            label: t(I18nKey.AUTOMATIONS$DELETE),
            icon: <TrashIcon className="size-4" />,
            onClick: onDelete,
          },
        ]
      : []),
  ];

  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-start justify-between">
        <div className="flex items-center gap-3">
          <h1 className="text-xl font-medium text-content">
            {automation.name}
          </h1>
          <ActiveStatusBadge automation={automation} />
        </div>
        <div className="flex items-center gap-2">
          {canManage && onRunNow && (
            <button
              type="button"
              className="inline-flex items-center gap-1.5 rounded-md border border-border px-3 py-1.5 text-sm font-medium text-content transition-colors hover:bg-surface-raised disabled:cursor-not-allowed disabled:opacity-60"
              disabled={isRunningNow || !automation.enabled}
              onClick={onRunNow}
            >
              <PlayIcon className="size-3.5 shrink-0" aria-hidden />
              {isRunningNow
                ? t(I18nKey.AUTOMATIONS$STARTING)
                : t(I18nKey.AUTOMATIONS$RUN_NOW)}
            </button>
          )}
          {canToggle && (
            <ToggleSwitch
              enabled={automation.enabled}
              label={
                automation.enabled
                  ? t(I18nKey.AUTOMATIONS$TURN_OFF)
                  : t(I18nKey.AUTOMATIONS$TURN_ON)
              }
              onToggle={onToggle}
            />
          )}
          <KebabMenu items={kebabItems} />
        </div>
      </div>
    </div>
  );
}
