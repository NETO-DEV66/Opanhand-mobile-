import { cn } from "#/utils/utils";
import { dropdownInstantColorClassName } from "#/utils/dropdown-classes";

export const automationIconActionButtonClassName = cn(
  "inline-flex size-8 shrink-0 cursor-pointer items-center justify-center rounded-md border-0 bg-transparent text-muted hover:bg-interactive-hover hover:text-contrast focus-visible:outline-none disabled:cursor-not-allowed disabled:opacity-50 disabled:hover:bg-transparent disabled:hover:text-muted",
  dropdownInstantColorClassName,
);
