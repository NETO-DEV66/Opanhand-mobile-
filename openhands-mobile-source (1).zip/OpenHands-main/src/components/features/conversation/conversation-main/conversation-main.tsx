import { useEffect, useMemo, useState } from "react";
import { FileText, MessageSquare } from "lucide-react";
import { useTranslation } from "react-i18next";
import { cn } from "#/utils/utils";
import { ChatActionTooltip } from "#/components/features/chat/chat-action-tooltip";
import BlockDrawerLeftIcon from "#/icons/block-drawer-left.svg?react";
import { mobileTopBarIconButtonClassName } from "#/utils/mobile-top-bar-icon-button-classes";
import { ChatInterfaceWrapper } from "./chat-interface-wrapper";
import { ConversationTabContent } from "../conversation-tabs/conversation-tab-content/conversation-tab-content";
import { ConversationNameWithStatus } from "../conversation-name-with-status";
import { ConversationTabs } from "../conversation-tabs/conversation-tabs";
import { ResizeHandle } from "../../../ui/resize-handle";
import { useResizablePanels } from "#/hooks/use-resizable-panels";
import { useConversationStore } from "#/stores/conversation-store";
import { AUTOMATION_SETUP_SHOW_AGENT_EVENT } from "#/components/features/automations/setup/automation-setup-agent-request";
import { AutomationSetupPanel } from "#/components/features/automations/setup/automation-setup-panel";
import { consumeAutomationSetupHandoff } from "#/api/automation-setup-handoff-store";
import type { AutomationSetupDraft } from "#/api/automation-setup-types";
import { useConversationId } from "#/hooks/use-conversation-id";
import {
  useBreakpoint,
  SIDEBAR_RAIL_COLLAPSE_MAX_WIDTH,
} from "#/hooks/use-breakpoint";
import { SidebarMobileMenuToggle } from "#/components/features/sidebar/sidebar-mobile-menu-toggle";
import { ConversationOverviewDrawer } from "../conversation-overview-drawer";
import { useConversationOverviewDrawerOptional } from "../conversation-overview-drawer-context";
import { useActiveConversation } from "#/hooks/query/use-active-conversation";
import { I18nKey } from "#/i18n/declaration";
import { hasAutomationSetupModeTag } from "#/utils/automation-draft-tags";

const BLANK_AUTOMATION_SETUP_DRAFT: AutomationSetupDraft = {
  prompt: "",
  kind: "prompt",
};

type MobileAutomationView = "form" | "conversation";

const MOBILE_AUTOMATION_VIEW_OPTIONS: {
  view: MobileAutomationView;
  labelKey: I18nKey;
  Icon: typeof FileText;
}[] = [
  {
    view: "form",
    labelKey: I18nKey.AUTOMATION_SETUP$VIEW_FORM,
    Icon: FileText,
  },
  {
    view: "conversation",
    labelKey: I18nKey.AUTOMATION_SETUP$VIEW_CONVERSATION,
    Icon: MessageSquare,
  },
];

function AutomationSetupDockedComposer({
  onTarget,
}: {
  onTarget: (element: HTMLDivElement | null) => void;
}) {
  return (
    <div className="custom-scrollbar-always pointer-events-none absolute inset-0 z-20 overflow-y-scroll px-5 [scrollbar-gutter:stable] [&::-webkit-scrollbar-thumb]:bg-transparent">
      <div className="relative mx-auto h-full w-full min-w-0 max-w-[800px]">
        <div
          ref={onTarget}
          data-testid="automation-setup-docked-composer"
          className="pointer-events-auto absolute inset-x-0 bottom-5 overflow-visible rounded-[15px] shadow-[0_12px_40px_rgba(0,0,0,0.55)]"
        />
      </div>
    </div>
  );
}

function getDesktopTabPanelClass(isRightPanelShown: boolean) {
  return isRightPanelShown
    ? "translate-x-0 opacity-100"
    : "w-0 translate-x-full opacity-0";
}

export function ConversationMain() {
  const { t } = useTranslation("openhands");
  const { conversationId } = useConversationId();
  const { data: conversation } = useActiveConversation();
  const isMobile = useBreakpoint();
  const isSidebarRailHidden = useBreakpoint(SIDEBAR_RAIL_COLLAPSE_MAX_WIDTH);
  const { isRightPanelShown, setHasRightPanelToggled, setIsRightPanelShown } =
    useConversationStore();
  // Derived per conversation during render: holding it in state reset by an
  // effect let the first render after a conversation switch reuse the previous
  // conversation's handoff, mounting the setup panel (which tags the
  // conversation as an automation setup) on the wrong conversation.
  const isAutomationSetupModeHandoff = useMemo(
    () => consumeAutomationSetupHandoff(conversationId),
    [conversationId],
  );
  const [automationToolbarElement, setAutomationToolbarElement] =
    useState<HTMLDivElement | null>(null);
  const [isAutomationAgentHidden, setIsAutomationAgentHidden] = useState(false);
  const [mobileAutomationView, setMobileAutomationView] =
    useState<MobileAutomationView>("form");
  const [composerDockTarget, setComposerDockTarget] =
    useState<HTMLDivElement | null>(null);
  const overviewDrawer = useConversationOverviewDrawerOptional();
  const isSecondaryDrawerOpen = Boolean(overviewDrawer?.section);
  const hasTaggedAutomationSetupMode = hasAutomationSetupModeTag(
    conversation?.tags,
  );
  const isAutomationSetupMode =
    isAutomationSetupModeHandoff || hasTaggedAutomationSetupMode;
  const automationSetupDraft = isAutomationSetupMode
    ? BLANK_AUTOMATION_SETUP_DRAFT
    : null;
  const showMobileAutomationForm =
    isMobile && isAutomationSetupMode && mobileAutomationView === "form";

  const { leftWidth, rightWidth, isDragging, containerRef, handleMouseDown } =
    useResizablePanels({
      defaultLeftWidth: 50,
      minLeftWidth: 30,
      maxLeftWidth: 80,
      storageKey: "desktop-layout-panel-width",
    });

  useEffect(() => {
    if (!automationSetupDraft) return;
    setHasRightPanelToggled(true);
    setIsRightPanelShown(true);
  }, [automationSetupDraft, setHasRightPanelToggled, setIsRightPanelShown]);

  useEffect(() => {
    if (!automationSetupDraft) {
      setIsAutomationAgentHidden(false);
    }
  }, [automationSetupDraft]);

  useEffect(() => {
    const showAgent = () => {
      setIsAutomationAgentHidden(false);
      setMobileAutomationView("conversation");
    };
    window.addEventListener(AUTOMATION_SETUP_SHOW_AGENT_EVENT, showAgent);
    return () =>
      window.removeEventListener(AUTOMATION_SETUP_SHOW_AGENT_EVENT, showAgent);
  }, []);

  const showDockedComposer = isAutomationSetupMode && isAutomationAgentHidden;
  const agentToggleLabel = isAutomationAgentHidden
    ? t(I18nKey.AUTOMATION_SETUP$SHOW_AGENT)
    : t(I18nKey.AUTOMATION_SETUP$HIDE_AGENT);
  const setupTitle =
    automationSetupDraft?.form?.name?.trim() ||
    conversation?.title ||
    t(I18nKey.AUTOMATION_SETUP$TITLE);

  return (
    <div
      className={cn(
        isMobile
          ? "relative min-h-0 flex-1 flex flex-col"
          : "h-full flex flex-col overflow-hidden",
      )}
    >
      {isAutomationSetupMode ? (
        <header
          data-testid="automation-setup-topbar"
          className={cn(
            "flex shrink-0 border-b border-[var(--oh-border)] bg-canvas-base",
            isMobile
              ? "flex-col"
              : "h-10 min-h-10 items-center justify-between gap-2 px-3",
          )}
        >
          <div
            className={cn(
              "flex min-w-0 items-center gap-2",
              isMobile && "h-10 justify-between px-3",
            )}
          >
            <div className="flex min-w-0 flex-1 items-center gap-2">
              {isSidebarRailHidden ? <SidebarMobileMenuToggle /> : null}
              <h2
                data-testid="automation-setup-conversation-title"
                className="min-w-0 truncate text-sm font-medium text-content"
              >
                {setupTitle}
              </h2>
            </div>
            {isMobile ? (
              <div
                role="group"
                aria-label={`${t(I18nKey.AUTOMATION_SETUP$VIEW_FORM)} / ${t(I18nKey.AUTOMATION_SETUP$VIEW_CONVERSATION)}`}
                className="flex shrink-0 overflow-hidden rounded-lg border border-[var(--oh-border)]"
              >
                {MOBILE_AUTOMATION_VIEW_OPTIONS.map(
                  ({ view, labelKey, Icon }) => {
                    const label = t(labelKey);
                    return (
                      <button
                        key={view}
                        type="button"
                        data-testid={`automation-setup-mobile-view-${view}`}
                        aria-label={label}
                        aria-pressed={mobileAutomationView === view}
                        title={label}
                        onClick={() => setMobileAutomationView(view)}
                        className={cn(
                          "inline-flex size-7 items-center justify-center",
                          mobileAutomationView === view
                            ? "bg-tertiary text-content"
                            : "text-[var(--oh-muted)]",
                        )}
                      >
                        <Icon className="size-4" aria-hidden />
                      </button>
                    );
                  },
                )}
              </div>
            ) : null}
          </div>
          <div
            className={cn(
              "flex min-w-0 items-center gap-1.5",
              isMobile ? "overflow-x-auto px-3 pb-2" : "shrink-0",
              isMobile && mobileAutomationView === "conversation" && "hidden",
            )}
          >
            <div
              ref={setAutomationToolbarElement}
              data-testid="automation-setup-toolbar"
              className="flex min-w-0 shrink-0 items-center gap-1.5"
            />
            {!isMobile ? (
              <ChatActionTooltip
                tooltip={agentToggleLabel}
                ariaLabel={agentToggleLabel}
              >
                <button
                  type="button"
                  data-testid="automation-setup-agent-toggle"
                  aria-label={agentToggleLabel}
                  aria-pressed={!isAutomationAgentHidden}
                  onClick={() =>
                    setIsAutomationAgentHidden((previous) => !previous)
                  }
                  className={cn(
                    mobileTopBarIconButtonClassName,
                    "size-7 self-center",
                  )}
                >
                  <BlockDrawerLeftIcon className="size-5 shrink-0" />
                </button>
              </ChatActionTooltip>
            ) : null}
          </div>
        </header>
      ) : null}

      <div
        ref={containerRef}
        className={cn(
          "flex flex-1 overflow-hidden",
          isMobile ? "flex-col" : "transition-all duration-300 ease-in-out",
        )}
        // transition toggled at runtime based on drag state
        style={
          !isMobile
            ? { transitionProperty: isDragging ? "none" : "all" }
            : undefined
        }
      >
        {/* Chat Panel - always mounted, styled differently for mobile/desktop.
            Owns its own header (name + status) and gets bottom padding so the
            chat input doesn't slam the floor. */}
        <div
          data-testid="conversation-chat-panel"
          className={cn(
            "flex flex-col bg-canvas-base overflow-hidden",
            isMobile
              ? cn("flex-1", showMobileAutomationForm && "hidden")
              : cn(
                  "min-w-0",
                  isAutomationSetupMode &&
                    isAutomationAgentHidden &&
                    "pointer-events-none opacity-0",
                  !isSecondaryDrawerOpen &&
                    "transition-[width] duration-300 ease-in-out",
                ),
          )}
          // panel width computed at runtime by resize hook; transition toggled by drag state
          style={
            !isMobile
              ? {
                  width:
                    isAutomationSetupMode && isAutomationAgentHidden
                      ? "0%"
                      : isRightPanelShown
                        ? `${leftWidth}%`
                        : "100%",
                  transitionProperty:
                    isDragging || isSecondaryDrawerOpen ? "none" : "width",
                }
              : undefined
          }
        >
          {!isAutomationSetupMode ? (
            <div
              data-testid="chat-pane-header"
              className={cn(
                "flex h-10 min-h-10 shrink-0 items-center",
                isSidebarRailHidden && "gap-2 pl-2.5",
              )}
            >
              {isSidebarRailHidden ? <SidebarMobileMenuToggle /> : null}
              <div className="min-w-0 flex-1">
                <ConversationNameWithStatus />
              </div>
            </div>
          ) : null}
          <div className="flex-1 min-h-0 flex flex-col">
            <ChatInterfaceWrapper
              isRightPanelShown={!isMobile && isRightPanelShown}
              showGitControlBar={!isAutomationSetupMode}
              showEmptyStateSuggestions={!isAutomationSetupMode}
              composerDockTarget={composerDockTarget}
              minimalComposer={isMobile && isAutomationSetupMode}
              composerPlaceholder={
                isAutomationSetupMode
                  ? t(
                      I18nKey.AUTOMATION_SETUP$CONVERSATION_COMPOSER_PLACEHOLDER,
                    )
                  : undefined
              }
              onDockedComposerSubmit={() => {
                setIsAutomationAgentHidden(false);
                setMobileAutomationView("conversation");
              }}
            />
          </div>
        </div>

        {/* Resize Handle - only shown on desktop when right panel is visible */}
        {!isMobile &&
          isRightPanelShown &&
          !(isAutomationSetupMode && isAutomationAgentHidden) && (
            <ResizeHandle
              onMouseDown={handleMouseDown}
              isDragging={isDragging}
            />
          )}

        {showMobileAutomationForm && automationSetupDraft ? (
          <div
            data-testid="automation-setup-mobile-form"
            className="relative flex min-h-0 flex-1 flex-col overflow-hidden"
          >
            <AutomationSetupPanel
              draft={automationSetupDraft}
              conversationId={conversationId}
              conversationTags={conversation?.tags}
              toolbarPortal={automationToolbarElement}
              showInlineHeader={false}
              reserveComposerSpace
            />
            <AutomationSetupDockedComposer onTarget={setComposerDockTarget} />
          </div>
        ) : null}

        {/* Right panel: desktop side drawer. Mobile opens Files/Tools via /panel route. */}
        {!isMobile && (
          <div
            data-testid="conversation-right-panel"
            className={cn(
              "transition-all duration-300 ease-in-out overflow-hidden",
              getDesktopTabPanelClass(isRightPanelShown),
            )}
            style={{
              width: isRightPanelShown
                ? isAutomationSetupMode && isAutomationAgentHidden
                  ? "100%"
                  : `${rightWidth}%`
                : "0%",
              transitionProperty: isDragging ? "opacity, transform" : "all",
            }}
          >
            <div className="flex h-full w-full flex-col">
              <div
                className={cn(
                  "relative flex flex-col flex-1 min-h-0 bg-surface overflow-hidden",
                  !(isAutomationSetupMode && isAutomationAgentHidden) &&
                    "border-l border-border",
                )}
              >
                {automationSetupDraft ? (
                  <AutomationSetupPanel
                    draft={automationSetupDraft}
                    conversationId={conversationId}
                    conversationTags={conversation?.tags}
                    toolbarPortal={automationToolbarElement}
                    showInlineHeader={false}
                    reserveComposerSpace={showDockedComposer}
                  />
                ) : (
                  <>
                    <div
                      data-testid="tabs-pane-header"
                      className="flex shrink-0 flex-col border-b border-border"
                    >
                      <ConversationTabs isPanelResizing={isDragging} />
                    </div>
                    <div className="flex-1 min-h-0 flex flex-col">
                      <ConversationTabContent />
                    </div>
                  </>
                )}
                {showDockedComposer ? (
                  // The setup form scrolls in a padded column with a stable
                  // scrollbar gutter. This overlay has to be a scroll container
                  // with the same gutter, or the composer centers in a wider
                  // box and sits off the fields.
                  <AutomationSetupDockedComposer
                    onTarget={setComposerDockTarget}
                  />
                ) : null}
              </div>
            </div>
          </div>
        )}
        <ConversationOverviewDrawer
          isMobile={isMobile}
          resizeContainerRef={containerRef}
        />
      </div>
    </div>
  );
}
