import React from "react";
import { LoaderCircle } from "lucide-react";
import { useTranslation } from "react-i18next";
import { I18nKey } from "#/i18n/declaration";
import { PastedImageUploadAsFileButton } from "./pasted-image-upload-as-file-button";
import { RemoveFileButton } from "./remove-file-button";

interface UploadedImageProps {
  image: File;
  onRemove: () => void;
  isLoading?: boolean;
  showUploadAsFileToggle?: boolean;
  uploadAsFileActive?: boolean;
  onToggleUploadAsFile?: () => void;
}

export function UploadedImage({
  image,
  onRemove,
  isLoading = false,
  showUploadAsFileToggle = false,
  uploadAsFileActive = false,
  onToggleUploadAsFile,
}: UploadedImageProps) {
  const { t } = useTranslation("openhands");
  const [imageUrl, setImageUrl] = React.useState<string>("");

  React.useEffect(() => {
    // Create object URL for image preview
    const url = URL.createObjectURL(image);
    setImageUrl(url);

    // Cleanup function to revoke object URL
    return () => {
      URL.revokeObjectURL(url);
    };
  }, [image]);

  return (
    <div className="group relative flex h-12.25 w-12.75 min-h-12.25 min-w-12.75 items-center justify-center rounded-lg bg-interactive-hover">
      {isLoading ? (
        <LoaderCircle className="animate-spin w-5 h-5" color="white" />
      ) : (
        imageUrl && (
          <img
            src={imageUrl}
            alt={image.name}
            className="h-full w-full rounded-lg object-cover"
          />
        )
      )}
      <RemoveFileButton
        onClick={onRemove}
        ariaLabel={t(I18nKey.BUTTON$REMOVE_IMAGE)}
      />
      {showUploadAsFileToggle && onToggleUploadAsFile && (
        <PastedImageUploadAsFileButton
          active={uploadAsFileActive}
          onToggle={onToggleUploadAsFile}
        />
      )}
    </div>
  );
}
